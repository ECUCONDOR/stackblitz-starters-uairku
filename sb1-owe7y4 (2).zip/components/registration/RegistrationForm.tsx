'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { z } from 'zod'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { BankSelector } from './BankSelector'
import { Upload } from 'lucide-react'

const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB

const formSchema = z.object({
  amount: z.number().min(1, 'El monto es requerido'),
  senderName: z.string().min(1, 'El nombre es requerido'),
  senderEmail: z.string().email('Email inválido'),
  beneficiaryName: z.string().min(1, 'El nombre del beneficiario es requerido'),
  beneficiaryDNI: z.string().min(7, 'DNI inválido'),
  beneficiaryCBU: z.string().regex(/^\d{22}$/, 'CBU debe tener 22 dígitos'),
  beneficiaryAlias: z.string().min(6, 'Alias inválido').optional(),
  ecucondorBank: z.string().min(1, 'Seleccione un banco'),
  receipt: z.any()
    .refine((file) => file?.length > 0, 'El comprobante es requerido')
    .refine(
      (file) => file?.[0]?.size <= MAX_FILE_SIZE,
      'El archivo no debe superar 5MB'
    )
    .refine(
      (file) => ['application/pdf', 'image/jpeg', 'image/png'].includes(file?.[0]?.type),
      'Solo se permiten archivos PDF, JPEG o PNG'
    )
})

type FormData = z.infer<typeof formSchema>

const BINANCE_API_URL = 'https://api.binance.com/api/v3/ticker/price?symbol=USDTARS'

export function RegistrationForm() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [exchangeRate, setExchangeRate] = useState(0)
  const [arsAmount, setArsAmount] = useState(0)

  const {
    register,
    watch,
    handleSubmit,
    formState: { errors }
  } = useForm<FormData>({
    resolver: zodResolver(formSchema)
  })

  const amount = watch('amount')

  useEffect(() => {
    const fetchExchangeRate = async () => {
      try {
        const response = await fetch(BINANCE_API_URL)
        const data = await response.json()
        setExchangeRate(parseFloat(data.price))
      } catch (error) {
        console.error('Error fetching exchange rate:', error)
      }
    }

    fetchExchangeRate()
    const interval = setInterval(fetchExchangeRate, 20000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (amount && exchangeRate) {
      const calculatedAmount = amount * exchangeRate * 0.965 // Apply 3.5% discount
      setArsAmount(calculatedAmount)
    } else {
      setArsAmount(0)
    }
  }, [amount, exchangeRate])

  const onSubmit = async (data: FormData) => {
    try {
      setIsSubmitting(true)
      const formData = new FormData()
      
      Object.keys(data).forEach(key => {
        if (key === 'receipt') {
          formData.append('receipt', data.receipt[0])
        } else {
          formData.append(key, data[key as keyof FormData]?.toString() || '')
        }
      })

      formData.append('arsAmount', arsAmount.toString())

      const response = await fetch('/api/register', {
        method: 'POST',
        body: formData
      })

      if (!response.ok) {
        throw new Error('Error al enviar el formulario')
      }

      router.push('/thank-you')
    } catch (error) {
      console.error('Error submitting form:', error)
      alert('Error al enviar el formulario. Por favor, inténtelo de nuevo.')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="bg-[#00264D]/50 backdrop-blur-sm border-cyan-400/20">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold text-cyan-400">
          Formulario de Registro
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="amount" className="text-cyan-400">
                Monto en USD
              </Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                {...register('amount', { valueAsNumber: true })}
                className="bg-white/5 border-cyan-400/20 text-white"
                placeholder="0.00"
              />
              {errors.amount && (
                <p className="text-red-500 text-sm">{errors.amount.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label className="text-cyan-400">Monto en ARS (3.5% descuento)</Label>
              <div className="bg-white/5 border border-cyan-400/20 rounded-md p-3 text-white">
                {arsAmount.toLocaleString('es-AR', {
                  style: 'currency',
                  currency: 'ARS'
                })}
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="senderName" className="text-cyan-400">
                Nombre Completo
              </Label>
              <Input
                id="senderName"
                {...register('senderName')}
                className="bg-white/5 border-cyan-400/20 text-white"
              />
              {errors.senderName && (
                <p className="text-red-500 text-sm mt-1">{errors.senderName.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="senderEmail" className="text-cyan-400">
                Correo Electrónico
              </Label>
              <Input
                id="senderEmail"
                type="email"
                {...register('senderEmail')}
                className="bg-white/5 border-cyan-400/20 text-white"
              />
              {errors.senderEmail && (
                <p className="text-red-500 text-sm mt-1">{errors.senderEmail.message}</p>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="beneficiaryName" className="text-cyan-400">
                Nombre del Beneficiario
              </Label>
              <Input
                id="beneficiaryName"
                {...register('beneficiaryName')}
                className="bg-white/5 border-cyan-400/20 text-white"
              />
              {errors.beneficiaryName && (
                <p className="text-red-500 text-sm mt-1">{errors.beneficiaryName.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="beneficiaryDNI" className="text-cyan-400">
                DNI del Beneficiario
              </Label>
              <Input
                id="beneficiaryDNI"
                {...register('beneficiaryDNI')}
                className="bg-white/5 border-cyan-400/20 text-white"
              />
              {errors.beneficiaryDNI && (
                <p className="text-red-500 text-sm mt-1">{errors.beneficiaryDNI.message}</p>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="beneficiaryCBU" className="text-cyan-400">
                CBU
              </Label>
              <Input
                id="beneficiaryCBU"
                {...register('beneficiaryCBU')}
                className="bg-white/5 border-cyan-400/20 text-white"
                placeholder="22 dígitos"
              />
              {errors.beneficiaryCBU && (
                <p className="text-red-500 text-sm mt-1">{errors.beneficiaryCBU.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="beneficiaryAlias" className="text-cyan-400">
                Alias (opcional)
              </Label>
              <Input
                id="beneficiaryAlias"
                {...register('beneficiaryAlias')}
                className="bg-white/5 border-cyan-400/20 text-white"
              />
              {errors.beneficiaryAlias && (
                <p className="text-red-500 text-sm mt-1">{errors.beneficiaryAlias.message}</p>
              )}
            </div>
          </div>

          <BankSelector register={register} errors={errors} />

          <div className="space-y-2">
            <Label htmlFor="receipt" className="text-cyan-400">
              Comprobante de Pago
            </Label>
            <div className="flex items-center gap-4">
              <Input
                id="receipt"
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                {...register('receipt')}
                className="bg-white/5 border-cyan-400/20 text-white file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-cyan-400 file:text-black hover:file:bg-cyan-300"
              />
              <Upload className="w-6 h-6 text-cyan-400" />
            </div>
            {errors.receipt && (
              <p className="text-red-500 text-sm">{errors.receipt.message}</p>
            )}
            <p className="text-xs text-cyan-400/70">
              Formatos aceptados: PDF, JPEG, PNG (máx. 5MB)
            </p>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-yellow-400 via-cyan-400 to-pink-500 text-black font-bold hover:opacity-90 disabled:opacity-50"
          >
            {isSubmitting ? 'Enviando...' : 'Enviar Registro'}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}