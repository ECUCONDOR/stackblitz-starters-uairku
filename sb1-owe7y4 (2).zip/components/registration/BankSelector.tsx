'use client'

import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export const ecucondorBanks = [
  { name: "Banco Pichincha", account: "Cuenta Corriente: 2100012345, RUC: 1234567890001" },
  { name: "Banco Guayaquil", account: "Cuenta de Ahorros: 1234567890, RUC: 1234567890001" },
  { name: "Banco del Pacífico", account: "Cuenta Corriente: 7654321098, RUC: 1234567890001" },
  { name: "Produbanco", account: "Cuenta de Ahorros: 12345-6, RUC: 1234567890001" },
  { name: "Banco Internacional", account: "Cuenta Corriente: 150-002345-6, RUC: 1234567890001" }
] as const

interface BankSelectorProps {
  register: any;
  errors: any;
}

export function BankSelector({ register, errors }: BankSelectorProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor="ecucondorBank" className="text-cyan-400">
        Seleccionar Banco
      </Label>
      <Select onValueChange={(value) => register('ecucondorBank').onChange({ target: { value } })}>
        <SelectTrigger id="ecucondorBank" className="bg-white/5 border-cyan-400/20 text-white">
          <SelectValue placeholder="Seleccione un banco" />
        </SelectTrigger>
        <SelectContent>
          {ecucondorBanks.map((bank) => (
            <SelectItem key={bank.name} value={bank.name}>
              {bank.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {errors.ecucondorBank && (
        <p className="text-red-500 text-sm">{errors.ecucondorBank.message}</p>
      )}
      <div className="text-sm text-cyan-400/70">
        {register('ecucondorBank').value && (
          <p>
            {ecucondorBanks.find(bank => bank.name === register('ecucondorBank').value)?.account}
          </p>
        )}
      </div>
    </div>
  )
}